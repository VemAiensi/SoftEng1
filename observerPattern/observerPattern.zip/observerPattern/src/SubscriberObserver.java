public interface SubscriberObserver {
    public void update(NewsAgency news);

}
